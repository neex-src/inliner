package libfoo;

public class Foo {
    public int bar() {
        return baz() + 1;
    }

    private int baz() {
        return 41;
    }
}
